module.exports = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
};