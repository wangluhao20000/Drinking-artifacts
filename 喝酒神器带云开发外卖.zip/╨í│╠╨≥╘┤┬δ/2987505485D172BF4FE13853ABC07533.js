var e = require("0DA5235785D172BF6BC34B5039017533.js"), t = require("D6A4661685D172BFB0C20E11F6007533.js");

module.exports = function(r, i) {
    return !i || "object" !== e(i) && "function" != typeof i ? t(r) : i;
};