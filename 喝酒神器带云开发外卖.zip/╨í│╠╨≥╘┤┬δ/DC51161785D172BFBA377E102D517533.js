Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.DING_API = exports.SERVER_SECRET_KEY = exports.HOST = exports.WS_HOST = exports.MIN_SUPPORT_VERSION = exports.VERSION = exports.DEV = void 0, 
exports.DEV = !1, exports.VERSION = "3.5.3", exports.MIN_SUPPORT_VERSION = "2.5.0", 
exports.WS_HOST = "wss://wx-drink-ws.afunapp.com/ws", exports.HOST = "https://wx-drink-ws.afunapp.com", 
exports.SERVER_SECRET_KEY = "P4EeJYQVt3tmcmtdaT9ipuPRfQbLdxvx", exports.DING_API = "https://oapi.dingtalk.com/robot/send?access_token=0cc64d6ae1fe3b26d9885ee68e5ed7ff986248fad7567fe09e34b2e761276c07";