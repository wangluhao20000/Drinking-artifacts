Component({
    properties: {},
    data: {},
    attached: function() {
        var t = null, n = [ "adunit-1b86d4cd3f847524", "adunit-1b7a044d714cdbd4", "adunit-38cc4479c450aab7", "adunit-81d66249128b8fd8", "adunit-a68288698494012f", "adunit-ea3e7749d998df0c", "adunit-4c877d937642c885", "adunit-3d4659f146d1f15d", "adunit-12965bc32dc614f3", "adunit-4e69e226cba89d98" ];
        wx.createInterstitialAd && ((t = wx.createInterstitialAd({
            adUnitId: n[Math.floor(9 * Math.random())]
        })).onLoad(function() {
            console.log("执行广告");
        }), t.onError(function(t) {
            console.log("广告报错", t);
        }), t.onClose(function() {
            console.log("广告关闭");
        }), setTimeout(function() {
            t.show().catch(function(t) {
                console.error(t);
            });
        }, 2500));
    },
    methods: {}
});