module.exports = function(r) {
    if (Array.isArray(r)) return r;
};