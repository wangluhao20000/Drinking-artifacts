Component({
    properties: {
        hbmoney: {
            type: [ Number, String ]
        },
        hbtip: {
            type: String
        },
        hbtipType: {
            type: String
        },
        hbbtntxt: {
            type: String
        },
        hbStatu: {
            type: [ Number, String ]
        }
    },
    data: {
        scale: ""
    },
    ready: function() {},
    methods: {}
});