Component({
    properties: {
        type: {
            type: String
        },
        hbtxt1: {
            type: String
        },
        hbtxt2: {
            type: String
        },
        maxMony: {
            type: String | Number
        },
        userStatus: {
            type: [ String, Number ]
        }
    },
    data: {},
    ready: function() {},
    methods: {}
});