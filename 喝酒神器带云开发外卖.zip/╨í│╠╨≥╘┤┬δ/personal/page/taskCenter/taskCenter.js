// personal/page/taskCenter/taskCenter.js
Page({data: {}})